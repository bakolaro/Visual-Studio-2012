using System;

/* Declare a boolean variable called isFemale and assign an
 * appropriate value corresponding to your gender.
 */

class AssignBool
{
   static void Main()
   {
      bool isFemale = false;
      string name = "Radoslav";
      Console.WriteLine("\"{0} is female\" is {1}.", name, isFemale);
   }
}

