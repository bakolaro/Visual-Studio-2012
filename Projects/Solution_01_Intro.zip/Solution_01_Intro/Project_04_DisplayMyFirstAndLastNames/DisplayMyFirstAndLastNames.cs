using System;

// Create console application that prints your first and last name.

class DisplayMyFirstAndLastNames
{
   static void Main()
   {
      Console.WriteLine("My name is Radoslav Lakov.");
   }
}
