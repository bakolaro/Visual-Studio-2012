using System;

// Create, compile and run a “Hello C#” console application.

class HelloCSharp
{
   static void Main()
   {
      Console.WriteLine("Hello, C#!");
   }
}