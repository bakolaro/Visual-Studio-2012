using System;

/* Create a console application that calculates and prints the
 * square of the number 12345.
 */

class SquareOfNumber12345
{
   static void Main()
   {
      Console.WriteLine(12345 * 12345);
   }
}
