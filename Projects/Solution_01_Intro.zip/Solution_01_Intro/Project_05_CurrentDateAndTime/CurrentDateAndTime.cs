using System;

// Create a console application that prints the current date and time.

class CurrentDateAndTime
{
   static void Main()
   {
      Console.WriteLine(DateTime.Now);
   }
}
